/*
 * DrivingExplore_Interface.c
 *
 *  Created on: 07.11.2019
 *      Author: Theo
 */


//#include "DrivingExplore_Interface.c"
//#include "PlatformConfiguration.h"
//#include "Driving.h"
//
//
//#define setDrivingStopFlag() setStopFlag(Val);
//
//#define getMeasurement()






